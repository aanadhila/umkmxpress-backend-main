<script src="https://maps.googleapis.com/maps/api/js?key={{ config('app.gmaps_api_key') }}&callback={{ $function }}" defer type="text/javascript"></script>
