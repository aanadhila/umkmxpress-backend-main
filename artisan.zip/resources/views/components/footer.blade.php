<div>
    <div id="kt_app_footer" class="app-footer">
        <div class="app-container container-fluid d-flex flex-column flex-md-row flex-center flex-md-stack py-3">
            <div class="text-dark order-2 order-md-1">
                <span class="text-muted fw-semibold me-1">{{ date('Y') }}©</span>
                <a href="{{ route('home') }}" target="_blank" class="text-gray-800 text-hover-primary">{{ config('app.name', 'Logistic Management') }}</a>
            </div>
            <ul class="menu menu-gray-600 menu-hover-primary fw-semibold order-1">
                <li class="menu-item">
                    <a href="{{ route('home') }}" target="_blank" class="menu-link px-2">About</a>
                </li>
                <li class="menu-item">
                    <a href="{{ route('home') }}" target="_blank" class="menu-link px-2">Support</a>
                </li>
            </ul>
        </div>
    </div>
</div>
