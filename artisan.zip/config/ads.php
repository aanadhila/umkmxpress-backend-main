<?php

return [
    'rajaongkir_api_key'            => env('RAJAONGKIR_API_KEY', null),
    'account_key'                   => env('ADS_ACCOUNT_KEY', null),
    'service_key'                   => env('ADS_SERVICE_KEY', null),
    'otp_service_secret_key'        => env('ADS_OTP_SECRET_KEY', null),
    'otp_url'                       => env('ADS_OTP_URL', null),
];
