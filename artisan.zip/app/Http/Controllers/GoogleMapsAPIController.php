<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class GoogleMapsAPIController extends Controller
{
    private $key;

    public function __construct()
    {
        $this->key = config('app.gmaps_api_key');
    }

    public function getDistance(Request $request, $origin = null, $destination = null)
    {
        try {
            $url = 'https://maps.googleapis.com/maps/api/distancematrix/json?key=' . $this->key . '&origins=' . ($origin ?? $request->origin) . '&destinations=' . ($destination ?? $request->destination);
            return Http::get($url)->getBody();
        } catch (\Throwable $th) {
            return $th->getMessage();
        }
    }
}
