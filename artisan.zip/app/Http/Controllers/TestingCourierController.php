<?php

namespace App\Http\Controllers;

use App\Models\Shipment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TestingCourierController extends Controller
{
    public function index()
    {
        $schedule = Carbon::today()->setTime(12, 0, 0);

        $now = Carbon::now();
        // $now = Carbon::today()->setTime(10,0,0);

        $shipments = Shipment::where('courier_id', auth()->user()->courier->id)
            ->whereBetween('created_at', [Carbon::yesterday()->setTime(12, 0, 0), Carbon::today()->setTime(11, 59, 59)])
            ->when($now->lessThan($schedule), function ($query) {
                return $query->whereIn('status', [1, 2]);
            })
            ->when($now->greaterThanOrEqualTo($schedule), function ($query) {
                return $query->whereIn('status', [3, 4])
                    ->orWhere(function ($query) {
                        $query->where('status', 5)->whereRelation('payment', 'status', 1);
                    });
            })
            ->where('status', '!=', 6)
            ->orderBy('created_at', 'asc')
            ->first();
        return view('courier.orders.pickup', ['shipment' => $shipments]);
    }

    public function pickup(Request $request)
    {
        DB::beginTransaction();
        $shipment = Shipment::where('id', $request->shipment_id)->first();

        // Flow kurir melakukan pickup shipment
        if ($shipment->status == 1) {
            $courierBalance = $shipment->courier->wallet->balance;
            $totalPrice = $shipment->total_price - $shipment->payment->method->cost;
            if ($courierBalance < $totalPrice) return back()->with('error', 'Saldo anda tidak mencukupi, silahkan lakukan top up saldo terlebih dahulu!');
            $shipment->status = 2;
            $shipment->save();
            $shipment->courier->wallet()->update([
                'balance'   => $shipment->courier->wallet->balance - $totalPrice
            ]);
            $shipment->courier->wallet->transaction()->create([
                'type'      => 4,
                'amount'    => $totalPrice,
                'status'    => 2,
                'note'      => config('data.transaction_type')[4] . ' ' . $shipment->airway_bill,
            ]);
            $shipment->trackers()->create([
                'note'      => config('data.shipment_status')[2]['note'],
                'status'    => 2,
            ]);
            DB::commit();
            return to_route('testing.orders.index')->with('warning', 'Segera menuju lokasi pickup!');
        }

        // Flow kurir tiba di lokasi pickup dan mengambil barang
        else if ($shipment->status == 2) {
            $request->validate(['pickup_photo' => 'required|mimes:png,jpg'], ['pickup_photo.required' => 'Upload foto pickup terlebih dahulu!']);
            $photo      = $request->file('pickup_photo');
            if ($photo) {
                $photo_name = $shipment->airway_bill . '_pickup_' . $photo->getClientOriginalExtension();
                $photo_path = $photo->storeAs('shipment', $photo_name, 'public');
            }
            $shipment->pickup_photo = $photo_path;
            $shipment->status = 3;
            $shipment->save();
            $shipment->trackers()->create([
                'note'      => config('data.shipment_status')[3]['note'],
                'status'    => 3,
            ]);
            $courier = $shipment->courier;
            if ($courier->shipments()->where('status', 2)->count() > 0) {
                DB::commit();
                return to_route('testing.orders.index')->with('warning', 'Pesanan berhasil dipickup!, Segera pickup pesanan lain!');
            } else {
                DB::commit();
                return to_route('testing.orders.index')->with('success', 'Semua pesanan telah dipickup, silahkan tunggu hingga waktu pengantaran!');
            }
        }

        // Flow kurir mengantarkan pesanan
        else if ($shipment->status == 3) {
            $shipment->status = 4;
            $shipment->save();
            $shipment->trackers()->create([
                'note'      => config('data.shipment_status')[4]['note'],
                'status'    => 4,
            ]);
            $courier = $shipment->courier;
            if ($courier->shipments()->where('status', 3)->count() > 0) {
                DB::commit();
                return to_route('testing.orders.index')->with('warning', 'Pesanan dalam proses diantarkan, segera proses pesanan lain!');
            } else {
                DB::commit();
                return to_route('testing.orders.index')->with('success', 'Semua pesanan dalam proses pengantaran, segera lakukan proses pengantaran!');
            }
        }

        // Flow kurir tiba di tempat pengantaran
        else if ($shipment->status == 4) {
            $request->validate(['delivered_photo' => 'required|mimes:png,jpg'], ['delivered_photo.required' => 'Upload foto barang terkirim terlebih dahulu!']);
            $photo      = $request->file('delivered_photo');
            if ($photo) {
                $photo_name = $shipment->airway_bill . '_delivered_' . $photo->getClientOriginalExtension();
                $photo_path = $photo->storeAs('shipment', $photo_name, 'public');
            }
            $shipment->delivered_photo = $photo_path;
            $shipment->status = 5;
            $shipment->save();
            $shipment->trackers()->create([
                'note'      => config('data.shipment_status')[5]['note'],
                'status'    => 5,
            ]);
            $courier = $shipment->courier;
            if ($courier->shipments()->where('status', 4)->count() > 0) {
                DB::commit();
                return to_route('testing.orders.index')->with('warning', 'Pesanan berhasil diantar, selesaikan pembayaran!');
            } else {
                DB::commit();
                return to_route('testing.orders.index')->with('success', 'Semua pesanan telah diantarkan!');
            }
        }

        // Flow penyelesaian pembayaran
        else if ($shipment->status == 5) {
            $shipment->payment()->update([
                'status' => 2,
            ]);
            $shipment->payment->histories()->create([
                'note'      => 'Pembayaran pengiriman ' . $shipment->airway_bill,
                'credit'    => 0,
                'debit'     => $shipment->payment->total_payment,
            ]);
            $courier = $shipment->courier;
            if ($courier->shipments()->where('status', 4)->count() > 0) {
                DB::commit();
                return to_route('testing.orders.index')->with('warning', 'Pesanan berhasil diselesaikan, segera antarkan pesanan lain!');
            } else {
                DB::commit();
                return to_route('testing.orders.index')->with('success', 'Semua pesanan telah diselesaikan!');
            }
        }
    }
}
